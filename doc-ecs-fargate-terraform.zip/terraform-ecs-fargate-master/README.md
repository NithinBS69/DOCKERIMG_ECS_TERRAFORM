Source code for a [tutorial on Medium](https://medium.com/@bradford_hamilton/deploying-containers-on-amazons-ecs-using-fargate-and-terraform-part-2-2e6f6a3a957f) I recently published.

Terraform config for deploying docker containers to ECS using Fargate launch type. Currently set up for my [Crystal Blockchain Application](https://github.com/bradford-hamilton/crystal-blockchain).

### Show your support

Give a ⭐ if this project was helpful in any way!